//
// Created by wengz on 2022/4/24.
//

#ifndef RAYTRACINGONEWEEKEND_IMAGE_SAVER_H
#define RAYTRACINGONEWEEKEND_IMAGE_SAVER_H
#define STB_IMAGE_WRITE_IMPLEMENTATION

#include "stb_image_write.h"

class image_saver {
public:
    image_saver() = default;

    image_saver(uint32_t w, uint32_t h) : wide(w), height(h) {
        data = (uint8_t *) malloc(wide * height * 4);
        memset(data, 0, wide * height * 4);
    };

    void save(const std::string &filename) const {
        stbi_write_png(filename.c_str(), wide, height, 4, data, wide * 4);
    }

    void write_color_buff(uint32_t w, uint32_t h, const color &c, int samples_per_pixel) noexcept {
        float r = c.x();
        float g = c.y();
        float b = c.z();
        auto rate = 1.0 / samples_per_pixel;

        r = sqrt(rate * r);
        g = sqrt(rate * g);
        b = sqrt(rate * b);
        data[4 * wide * h + 4 * w + 0] = static_cast<int>(256 * clamp(r, 0.0, 0.999));
        data[4 * wide * h + 4 * w + 1] = static_cast<int>(256 * clamp(g, 0.0, 0.999));
        data[4 * wide * h + 4 * w + 2] = static_cast<int>(256 * clamp(b, 0.0, 0.999));
        data[4 * wide * h + 4 * w + 3] = 255;
    }

    uint32_t wide;
    uint32_t height;
    uint8_t *data;

    ~image_saver() {
        free(data);
    }
};


#endif //RAYTRACINGONEWEEKEND_IMAGE_SAVER_H
