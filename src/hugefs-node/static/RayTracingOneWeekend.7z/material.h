//
// Created by wengz on 2022/4/24.
//

#ifndef _MATERIAL_H
#define _MATERIAL_H

#include "ray.h"


struct hit_record;

class material {
public:
    material() {};

    virtual std::tuple<bool, ray, vec3> scatter(const ray &r_in, const hit_record &rec) const = 0;
};

class lambertian : public material {
public:
    lambertian(const vec3 &a) : albedo(a) {}

    virtual std::tuple<bool, ray, vec3> scatter(const ray &r_in, const hit_record &rec) const;

private:
    const vec3 albedo;
};

class metal : public material {
public:
    metal(const vec3 &a) : albedo(a), fuzz(0.0f) {}

    metal(const vec3 &a, float f) : albedo(a), fuzz(f < 1.0f ? f : 1.0f) {}

    virtual std::tuple<bool, ray, vec3> scatter(const ray &r_in, const hit_record &rec) const;

    const vec3 albedo;
    const float fuzz;
};

class dielectric : public material {
public:
    dielectric(float ri, const vec3 &a) : albedo(a), ref_idx(ri) {}

    virtual std::tuple<bool, ray, vec3> scatter(const ray &r_in, const hit_record &rec) const;

private:
    float ref_idx;
    const vec3 albedo;
};

#endif //RAYTRACINGONEWEEKEND_MATERIAL_H
