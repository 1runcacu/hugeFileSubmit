//
// Created by wengz on 2021/8/17.
//

#include "hittable_list.h"

//bool hittable_list::hit(const ray &r, double t_min, double t_max, hit_record &rec) const {
//    hit_record rec_temp;
//    bool hit_any= false;
//    double closest_dis=t_max;
//    for(const auto& object:objects){
//        if(object->hit(r,t_min,closest_dis,rec_temp)){
//            hit_any= true;
//            closest_dis=rec_temp.t;
//            rec=rec_temp;
//        }
//    }
//    return hit_any;
//}
std::pair<bool, hit_record> hittable_list::hit(const ray &r, float t_min, float t_max) const {
    hit_record rec_temp;
    bool hit_any = false;
    float closest_dis = t_max;
    for (const auto &object: objects) {
        auto [status, rec_temp_] = object->hit(r, t_min, closest_dis);
        if (status) {
            rec_temp = rec_temp_;
            hit_any = true;
            closest_dis = rec_temp.t;
        }
    }
    return {hit_any, rec_temp};
}