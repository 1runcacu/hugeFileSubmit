//
// Created by wengz on 2021/8/16.
//

#include "ray.h"

point3 ray::at(double t) const {
    return orig + t * dir;
}
