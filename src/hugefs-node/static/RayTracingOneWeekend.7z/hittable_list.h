//
// Created by wengz on 2021/8/17.
//

#ifndef RAYTRACINGONEWEEKEND_HITTABLE_LIST_H
#define RAYTRACINGONEWEEKEND_HITTABLE_LIST_H
#include "hittable.h"
#include <memory>
#include <vector>

using std::shared_ptr;
using std::vector;
using std::make_shared;

class hittable_list :public hittable{
public:
    vector<shared_ptr<hittable>> objects;
    hittable_list(){};
    //hittable_list(const shared_ptr<hittable>& object){add(object);}
    hittable_list(shared_ptr<hittable> object){add(object);}
    void add(shared_ptr<hittable> object){
        objects.push_back(object);
    }
    void clear(){
        objects.clear();
    }
    //virtual bool hit(const ray& r,double t_min,double t_max,hit_record& rec) const override;
    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const;

};


#endif //RAYTRACINGONEWEEKEND_HITTABLE_LIST_H
