//
// Created by wengz on 2021/8/16.
//

#ifndef RAYTRACINGONEWEEKEND_COLOR_H
#define RAYTRACINGONEWEEKEND_COLOR_H

#include "vec3.h"
#include "iostream"
#include "image_saver.h"

void write_color(std::ostream &out, color c, int samples_per_pixel) {
    double r = c.x();
    double g = c.y();
    double b = c.z();
    auto rate = 1.0 / samples_per_pixel;
    r *= rate;
    g *= rate;
    b *= rate;
    out << static_cast<int>(256 * clamp(r, 0.0, 0.999)) << ' ' << static_cast<int>(256 * clamp(g, 0.0, 0.999)) << ' '
        << static_cast<int>(256 * clamp(b, 0.0, 0.999)) << std::endl;
}

//void parallel_write_color_buff(image_saver& saver, uint32_t w, uint32_t h, color c, int samples_per_pixel) {
//    double r = c.x();
//    double g = c.y();
//    double b = c.z();
//    auto rate = 1.0 / samples_per_pixel;
//    r *= rate;
//    g *= rate;
//    b *= rate;
//    saver.data[4 * saver.wide * h + 4 * w + 0]=static_cast<int>(256 * clamp(r, 0.0, 0.999));
//    saver.data[4 * saver.wide * h + 4 * w + 1]=static_cast<int>(256 * clamp(g, 0.0, 0.999));
//    saver.data[4 * saver.wide * h + 4 * w + 2]=static_cast<int>(256 * clamp(b, 0.0, 0.999));
//    saver.data[4 * saver.wide * h + 4 * w + 3]=255;
//}

#endif //RAYTRACINGONEWEEKEND_COLOR_H
