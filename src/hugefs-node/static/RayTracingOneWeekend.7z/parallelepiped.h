//
// Created by wengz on 2022/4/25.
//

#ifndef RAYTRACINGONEWEEKEND_PARALLELEPIPED_H
#define RAYTRACINGONEWEEKEND_PARALLELEPIPED_H

#include "hittable.h"

class parallelepiped : public hittable {
public:
    shared_ptr<material> m_ptr;

    parallelepiped() {};

    parallelepiped(point3 p0, point3 p1, point3 p2, point3 p3, shared_ptr<material> m);

    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const override;

private:
//    point3 top_points[4];
//    point3 bot_points[4];
    std::array<shared_ptr<surface4>, 6> surfaces{};
};

parallelepiped::parallelepiped(point3 p0, point3 p1, point3 p2, point3 p3, shared_ptr<material> m) :
        m_ptr(std::move(m)) {

    vec3 v1 = p1 - p0;
    vec3 v2 = p2 - p0;
    vec3 v3 = p3 - p0;
    if (dot(cross(v1, v2), v3) < 0) {
        std::swap(v1, v2);
        std::swap(p1, p2);
    }
    point3 p4 = p0 + v1 + v2;
    point3 p5 = p0 + v1 + v3;
    point3 p6 = p0 + v2 + v3;
    //point3 p7 = p0 + v1 + v2 + v3;

    surfaces[0] = make_shared<surface4>(p0, p2, p1);
    surfaces[1] = make_shared<surface4>(p0, p1, p3);
    surfaces[2] = make_shared<surface4>(p0, p3, p2);
    surfaces[3] = make_shared<surface4>(p1, p4, p5);
    surfaces[4] = make_shared<surface4>(p2, p6, p4);
    surfaces[5] = make_shared<surface4>(p3, p5, p6);
}

std::pair<bool, hit_record> parallelepiped::hit(const ray &r, float t_min, float t_max) const {
    hit_record rec_temp;
    bool hit_any = false;
    float closest_dis = t_max;
    for (const auto &surface: surfaces) {
        auto [status, rec_temp_] = surface->hit(r, t_min, closest_dis);
        if (status) {
            rec_temp.hitpoint = rec_temp_.hitpoint;
            rec_temp.t = rec_temp_.t;
            rec_temp.n=rec_temp_.n;
            rec_temp.isFace2Face=rec_temp_.isFace2Face;
            hit_any = true;
            closest_dis = rec_temp.t;
        }
    }
    if (hit_any) rec_temp.m_ptr = m_ptr;
    return {hit_any, rec_temp};
}

#endif //RAYTRACINGONEWEEKEND_PARALLELEPIPED_H
