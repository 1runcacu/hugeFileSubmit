//
// Created by wengz on 2022/4/24.
//

#include "material.h"
#include "hittable.h"

std::tuple<bool, ray, vec3> lambertian::scatter(const ray &r_in, const hit_record &rec) const {
    vec3 scatter_dir = rec.n + random_unit_vector();//漫反射
    ray scattered = ray(rec.hitpoint, scatter_dir);
    vec3 attenuation = this->albedo;
    return {true, scattered, attenuation};
}

std::tuple<bool, ray, vec3> metal::scatter(const ray &r_in, const hit_record &rec) const {
    vec3 reflected = reflect(unit_vector(r_in.direction()), rec.n);//反射方向
    ray scattered = ray(rec.hitpoint, reflected + fuzz * random_unit_vector());//生成反射线
    vec3 attenuation = this->albedo;
    return {(dot(scattered.direction(), rec.n) > 0), scattered, attenuation};
}

std::tuple<bool, ray, vec3> dielectric::scatter(const ray &r_in, const hit_record &rec) const {
    vec3 attenuation = this->albedo;
    float rate;
    if (rec.isFace2Face) {
        rate = 1.0f/ref_idx;
        //attenuation={1,0,0};
    } else {
        rate = ref_idx;
        //attenuation={1,1,1};
    }
    vec3 dir = unit_vector(r_in.direction());
    float cos_theta=std::min(dot(-dir,rec.n),1.0f);
    float sin_theta=std::sqrt(1-cos_theta*cos_theta);
    if(rate*sin_theta>1.0f){
        vec3 reflected= reflect(dir,rec.n);
        ray scattered=ray(rec.hitpoint,reflected);
        return {true,scattered, attenuation};
    }
    vec3 refracted = refract(dir, rec.n, rate);
    ray scattered = ray(rec.hitpoint, refracted);
    return {true, scattered, attenuation};
}
