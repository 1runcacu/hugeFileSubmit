//
// Created by wengz on 2021/8/16.
//

#ifndef RAYTRACINGONEWEEKEND_VEC3_H
#define RAYTRACINGONEWEEKEND_VEC3_H

#include <cmath>
#include <iostream>
#include "Utilities.h"

using std::sqrt;

class vec3 {
public:
    double e[3];

    vec3() : e{0, 0, 0} {}

    vec3(double e0, double e1, double e2) : e{e0, e1, e2} {}

    double x() const;

    double y() const;

    double z() const;

    vec3 operator-() const;

    double operator[](int i) const;

    double &operator[](int i);

    vec3 &operator+=(const vec3 &v);

    vec3 &operator*=(const double t);

    vec3 &operator/=(const double t);


    double length() const;

    double length_squared() const;

    inline static vec3 random(double min, double max) {
        return vec3(random_double(min, max), random_double(min, max), random_double(min, max));
    }

    inline static vec3 random() {
        return vec3(random_double(), random_double(), random_double());
    }

};

using point3 = vec3;
using color = vec3;

inline std::ostream &operator<<(std::ostream &out, const vec3 v) {
    return out << v.e[0] << ' ' << v.e[1] << ' ' << v.e[2];
}

inline vec3 operator+(const vec3 &u, const vec3 &v) {
    return vec3(u.e[0] + v.e[0], u.e[1] + v.e[1], u.e[2] + v.e[2]);
}

inline vec3 operator-(const vec3 &u, const vec3 &v) {
    return vec3(u.e[0] - v.e[0], u.e[1] - v.e[1], u.e[2] - v.e[2]);
}

inline vec3 operator*(const vec3 &u, const double t) {
    return vec3(u.e[0] * t, u.e[1] * t, u.e[2] * t);
}

inline vec3 operator*(const double t, const vec3 &u) {
    return u * t;
}

inline vec3 operator/(const vec3 &u, const double t) {
    return u * (1 / t);
}

inline vec3 operator*(const vec3 &u, const vec3 &v) {
    return vec3(u[0] * v[0], u[1] * v[1], u[2] * v[2]);
}

inline double dot(const vec3 &u, const vec3 &v) {
    return u.e[0] * v.e[0] + u.e[1] * v.e[1] + u.e[2] * v.e[2];
}

inline vec3 cross(const vec3 &u, const vec3 &v) {
    return vec3(u.e[1] * v.e[2] - u.e[2] * v.e[1],
                u.e[2] * v.e[0] - u.e[0] * v.e[2],
                u.e[0] * v.e[1] - u.e[1] * v.e[0]);
}

inline vec3 unit_vector(const vec3 &v) {
    return v / v.length();
}

inline vec3 random_in_unit_sphere() {
    while (true) {
        auto p = vec3::random(-1, 1);
        if (p.length_squared() > 1.0) continue;
        return p;
    }
};

inline vec3 random_unit_vector() {
    double theta = random_double(0, 2 * pi);
    double z = random_double(-1, 1);
    double r = std::sqrt(1 - z * z);
    return vec3(r * std::cos(theta), r * std::sin(theta), z);
}

inline vec3 reflect(const vec3 &v, const vec3 &n) {
    return v - 2 * dot(v, n) * n;
}

#endif //RAYTRACINGONEWEEKEND_VEC3_H
