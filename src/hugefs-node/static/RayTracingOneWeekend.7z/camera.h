//
// Created by wengz on 2021/8/17.
//

#ifndef RAYTRACINGONEWEEKEND_CAMERA_H
#define RAYTRACINGONEWEEKEND_CAMERA_H


#include "Utilities.h"

class camera {
public:
    camera() {
//        const int width = 400;
//        const int height = static_cast<int>(width / image_size_rate);

        const double image_size_rate = 16.0 / 9.0;
        const double viewport_height = 2.0;
        const double viewport_width = viewport_height * image_size_rate;
        const double focal_distance = 1.0;//视窗位置

        origin = point3(0, 0, 0);//参考点
        pos = point3(0, 0, 16);//相机自己的位置

        horizontal = vec3(viewport_width, 0, 0); //视口平面的基向量
        vertical = vec3(0, viewport_height, 0);

        lower_left_corner = origin - horizontal * 0.5 - vertical * 0.5 - vec3(0, 0, focal_distance); //视口左下角边角
    }

    ray get_ray(double u, double v) {
        return ray(pos, lower_left_corner + u * horizontal + v * vertical - pos);
    }

private:
    point3 origin;
    point3 lower_left_corner;
    vec3 horizontal;
    vec3 vertical;
    point3 pos;

};

#endif //RAYTRACINGONEWEEKEND_CAMERA_H
