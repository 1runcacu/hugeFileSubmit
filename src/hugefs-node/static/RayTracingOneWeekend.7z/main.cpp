#include <iostream>
#include "Utilities.h"
#include "hittable_list.h"
#include "sphere.h"
#include "camera.h"
#include "tbb/blocked_range.h"
#include "tbb/blocked_range2d.h"
#include "tbb/parallel_for.h"
#include "image_saver.h"
#include "material.h"
#include "ticktock.h"
#include "parallelepiped.h"
#include "tetrahedron.h"

color ray_color(const ray &r, const hittable_list &world, int depth) {
    if (depth <= 0) {
        return {0, 0, 0};
    }
    auto [status, rec] = world.hit(r, 0.001f, infinity);
    if (status) {
        auto [status2, scattered, attenuation] = rec.m_ptr->scatter(r, rec);
        //printf("%f\n",attenuation);
        if (status2) {
            return attenuation * ray_color(scattered, world, depth - 1);
        } else {
            return {0, 0, 0};
        }

    } else {
        vec3 unit_vec = unit_vector(r.direction());
        return {1, 1, 1};
//        float t = 0.5f * (unit_vec.y() + 1.0f);
//        return (1.0f - t) * color(1, 1, 1) + t * color(0.5f, 0.7f, 1.0f);
    }
}


int main() {
    const double image_size_rate = 16.0 / 9.0;
    const int width = 2000;
    const int height = static_cast<int>(width / image_size_rate);
    const int sample_times = 64;
    const int max_depth = 128;

    hittable_list world;
    world.add(make_shared<sphere>(vec3(0, 0, -1), 0.5,
                                  make_shared<lambertian>(vec3(0.7f, 0.3f, 0.3f))));

    world.add(make_shared<sphere>(vec3(0, -100.5, -1), 100,
                                  make_shared<lambertian>(vec3(0.8f, 0.8f, 0.8f))));

//    world.add(make_shared<sphere>(vec3(1.1, 0, -1), 0.5,
//                                  make_shared<metal>(vec3(0.8f+0.5f, 0.6f+0.5f, 0.2f+0.5f), 0.1f)));
    world.add(make_shared<sphere>(vec3(-1.1, -0.1, -1), 0.4,
                                  make_shared<dielectric>(1.2, vec3(0.2f, 0.4f, 0.6f))));
    world.add(make_shared<sphere>(vec3(-1.1, -0.1, -1), 0.1,
                                  make_shared<metal>(vec3(0.5f, 0.6f, 0.8f), 0.1f)));
////
    world.add(make_shared<sphere>(vec3(-0.55, -0.25, 0.1), 0.25,
                                  make_shared<metal>(vec3(0.9f, 0.9f, 1.1f), 0.1f)));
////
////    world.add(make_shared<sphere>(vec3(0.55, -0.25, -0.1), 0.25,
////                                  make_shared<lambertian>(vec3(0.9f, 0.9f, 0.9f))));
    const float d = -0.6;
    world.add(make_shared<parallelepiped>(point3(-0.2f + d, 0, -3),
                                          point3(0.3f + d, 0.2, -3.5),
                                          point3(-0.3f + d, 0.2, -3.5),
                                          point3(-0.2f + d, 0.5, -3 + 0.2),
                                          make_shared<lambertian>(vec3(0.1f, 0.1f, 0.5f))));
//    world.add(make_shared<sphere>(vec3(-1,0,-1), 0.5, make_shared<dielectric>(1.5)));
//    world.add(make_shared<sphere>(vec3(-1,0,-1),0.5, make_shared<dielectric>(1.5)));
    world.add(make_shared<sphere>(vec3(0.6, -0.15, 0), 0.35, make_shared<dielectric>(1.5, vec3(0.5f, 0.5f, 0.8f))));
    world.add(make_shared<tetrahedron>(vec3(0.5136f + 0.6f, 0, -1.7435f),
                                       vec3(0.8243f + 0.6f, 0.2893f, -1.7585f),
                                       vec3(0.5286f + 0.6f, 0.3107f, -1.4543f),
                                       vec3(0.8182f + 0.6f, 0, -1.4475f),
                                       make_shared<dielectric>(1.5f, vec3(0.8f, 0.8f, 0.9f))));
    //world.add(make_shared<sphere>(vec3(0.65f+0.6f,2.0f,-4.0f),2.5f,make_shared<lambertian>(vec3(0.1f, 0.1f, 0.5f))));
    camera cam;
    image_saver saver(width, height);

    tbb::task_arena ta(12);
    ta.execute([&] {
        TICK(static_rendering_fm);
        tbb::parallel_for(tbb::blocked_range2d<int>(0, height, 50, 0, width, 50),
                          [&](tbb::blocked_range2d<int> &r) {
                              for (auto i_ = r.rows().begin(); i_ != r.rows().end(); i_++) {
                                  for (auto j = r.cols().begin(); j != r.cols().end(); j++) {
                                      auto i = height - i_ - 1;//世界坐标系
                                      color p(0, 0, 0);
                                      for (int k = 0; k < sample_times; k++) {
                                          float u = (float) (j + random_float()) / (width - 1.0f); //在视口平面上的归一化坐标
                                          float v = (float) (i + random_float()) / (height - 1.0f);
                                          ray ry = cam.get_ray(u, v);
                                          p += ray_color(ry, world, max_depth);
                                      }
                                      saver.write_color_buff(j, i_, p, sample_times);//屏幕坐标系
                                  }
                              }
                          }, tbb::simple_partitioner());
        TOCK(static_rendering_fm);
    });
    saver.save("test.png");


    return 0;
}
