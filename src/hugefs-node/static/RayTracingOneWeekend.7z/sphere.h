//
// Created by wengz on 2021/8/17.
//

#ifndef RAYTRACINGONEWEEKEND_SPHERE_H
#define RAYTRACINGONEWEEKEND_SPHERE_H



#include <utility>

#include "hittable.h"

class sphere : public hittable {
public:
    point3 center;
    float radius;
    shared_ptr<material> m_ptr;

    sphere() {};

    sphere(point3 cen, float R, shared_ptr<material> m) : center(cen), radius(R), m_ptr(std::move(m)) {};

    //bool hit(const ray &r, double t_min, double t_max, hit_record &rec) const override;
    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const override;
};

std::pair<bool, hit_record> sphere::hit(const ray &r, float t_min, float t_max) const {
    hit_record rec{};
    vec3 oc = r.origin() - center;
    float a = r.direction().length_squared();
    float half_b = dot(r.direction(), oc);
    float c = oc.length_squared() - radius * radius;
    float discriminant = half_b * half_b - a * c;
    if (discriminant > 0) {
        float sqrtdis = sqrt(discriminant);
        float t = (-half_b - sqrtdis) / a;
        if (t > t_min && t < t_max) {
            rec.t = t;
            rec.hitpoint = r.at(t);
            vec3 outside_n = (rec.hitpoint - center) / radius;
            rec.set_n_face2face(r, outside_n);
            rec.m_ptr = this->m_ptr;
            return {true, rec};
        }
        t = (-half_b + sqrtdis) / a;
        if (t > t_min && t < t_max) {
            rec.t = t;
            rec.hitpoint = r.at(t);
            vec3 outside_n = (rec.hitpoint - center) / radius;
            rec.set_n_face2face(r, outside_n);
            rec.m_ptr = this->m_ptr;
            return {true, rec};
        }
    }
    return {false, rec};
}


#endif //RAYTRACINGONEWEEKEND_SPHERE_H
