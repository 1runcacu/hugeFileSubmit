//
// Created by wengz on 2021/8/17.
//

#ifndef RAYTRACINGONEWEEKEND_HITTABLE_H
#define RAYTRACINGONEWEEKEND_HITTABLE_H

#include "ray.h"
#include "material.h"


//using hit_record = struct hit_record;

struct hit_record {
    point3 hitpoint; //交点
    vec3 n; //法向量
    float t; //距离
    std::shared_ptr<material> m_ptr;//材质指针
    bool isFace2Face; //法向量和光线是否相互面对

    inline void set_n_face2face(const ray &r, const vec3 &outside_n) {
        isFace2Face = dot(r.direction(), outside_n) < 0;
        n = isFace2Face ? outside_n : -outside_n;
    }
};

class hittable {
public:
    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const = 0;
};

//三角面
class surface3 {
public:
    surface3() {};
    surface3(point3 p0, point3 p1, point3 p2) : v0(p0), v1(p1), v2(p2) {
        vec3 s1 = p1 - p0;
        vec3 s2 = p2 - p0;
        n = unit_vector(cross(s1, s2));
    }

    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const {
        hit_record rec{};
        // E1
        vec3 E1 = v1 - v0;
        // E2
        vec3 E2 = v2 - v0;
        // P
        vec3 P = cross(r.dir, E2);
        // determinant
        float det = dot(E1, P);
        // keep det > 0, modify T accordingly
        vec3 T;
        if (det > 0) {
            T = r.orig - v0;
        } else {
            T = v0 - r.orig;
            det = -det;
        }
        // If determinant is near zero, ray lies in plane of triangle
        if (det < 0.0001f) {
            //rec.n = n;
            return {false, rec};
        }
        float u, v;
        // Calculate u and make sure u <= 1
        u = dot(T, P);
        if (u < 0.0f || u > det)
            return {false, rec};
        // Q
        vec3 Q = cross(T, E1);
        // Calculate v and make sure u + v <= 1
        v = dot(r.dir, Q);
        if (v < 0.0f || u + v > det)
            return {false, rec};

        // Calculate t, scale parameters, ray intersects triangle
        rec.t = dot(E2, Q);

        float fInvDet = 1.0f / det;
        rec.t *= fInvDet;
        if (rec.t > t_max || rec.t < t_min) {
            return {false, rec};
        }
        rec.n = n;
        rec.hitpoint = r.orig + r.dir * rec.t;
        rec.set_n_face2face(r,n);
        return {true, rec};
    }
private:
    vec3 n;//法向量
    point3 v0, v1, v2;
};


//平行四边形
class surface4 {
public:
    surface4() {};
    surface4(point3 p0, point3 p1, point3 p2):v0(p0),v1(p1),v2(p2){
        vec3 s1 = p1 - p0;
        vec3 s2 = p2 - p0;
        n = unit_vector(cross(s1, s2));
    }
    virtual std::pair<bool, hit_record> hit(const ray &r, float t_min, float t_max) const {
        hit_record rec{};
        // E1
        vec3 E1 = v1 - v0;
        // E2
        vec3 E2 = v2 - v0;
        // P
        vec3 P = cross(r.dir, E2);
        // determinant
        float det = dot(E1, P);
        // keep det > 0, modify T accordingly
        vec3 T;
        if (det > 0) {
            T = r.orig - v0;
        } else {
            T = v0 - r.orig;
            det = -det;
        }
        // If determinant is near zero, ray lies in plane of triangle
        if (det < 0.0001f) {
            //rec.n = n;
            return {false, rec};
        }
        float u, v;
        // Calculate u and make sure u <= 1
        u = dot(T, P);
        if (u < 0.0f || u > det)
            return {false, rec};
        // Q
        vec3 Q = cross(T, E1);
        // Calculate v and make sure u + v <= 1
        v = dot(r.dir, Q);
        if (v < 0.0f || v > det)
            return {false, rec};

        // Calculate t, scale parameters, ray intersects triangle
        rec.t = dot(E2, Q);

        float fInvDet = 1.0f / det;
        rec.t *= fInvDet;
        if (rec.t > t_max || rec.t < t_min) {
            return {false, rec};
        }
        rec.n = n;
        rec.hitpoint = r.orig + r.dir * rec.t;
        rec.set_n_face2face(r,n);
        return {true, rec};
    }

private:
    vec3 n;//法向量
    point3 v0, v1, v2;

};

#endif //RAYTRACINGONEWEEKEND_HITTABLE_H
